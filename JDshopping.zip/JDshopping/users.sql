﻿# Host: localhost  (Version: 5.5.53)
# Date: 2020-06-03 16:31:18
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "users"
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `repass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

#
# Data for table "users"
#

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','123456','管理员','',NULL,NULL),(2,'linzhu','888888','林珠','小确殇','2459556414@qq.com',NULL),(3,'xiaoyang','888888','小肥羊',NULL,NULL,NULL),(4,'linlin','1014','测试人员',NULL,NULL,NULL),(5,'yangyanf','0324','李杨',NULL,NULL,NULL),(6,'yangyang','0324','李杨',NULL,NULL,NULL),(7,'liyang','liyang','李杨',NULL,NULL,NULL),(12,'大主宰','asd980324','怪兽',NULL,NULL,NULL),(13,'大主宰','asd980324','怪兽',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
