 /*
  1. 获取 from 标签, 取消默认事件
    1-2. 绑定 submit 事件
    1-3. 取消默认事件
  2. 在表单提交事件里面获取用户输入的内容
    2-2. 获取用户输入的内容
    2-3. 表单验证(非空验证)
    2-4. 发送请求
  3. 根据后端的响应做对应的操作
    3-2. 登录失败的时候提示错误
    3-3. 登录成功的时候
      + 跳转页面
      + 留一个登陆过的证明
      + 把当前登录用户的昵称留在 cookie 里面
*/

// 1. 获取 form 标签
let form = document.querySelector('form')

// 2. 获取元素
let uname = document.querySelector('.username')
let upass = document.querySelector('.password')

// 3. 获取元素
let errText = document.querySelector('form > span')


// 1-2. 绑定事件
form.addEventListener('submit', e => {
  // 1-3. 取消默认事件
  // 处理事件对象兼容
  e = e || window.event
  // 取消默认事件
  e.preventDefault()

  // 2-2. 获取用户输入的内容
  let username = uname.value
  let password = upass.value

  // 2-3. 表单验证
  if (username === '' || password === '') {
    alert('请完整填写表单')
    return
  }

  // 2-4. 发送请求
  //      直接使用我们封装好的 ajax 方法
  ajax({
    url: '../server/login.php',
    type: 'POST',
    data: `username=${ username }&password=${ password }`,
    dataType: 'json',
    success: function (res) {
      // res => 后端返回的结果
      // console.log(res)

      // 3. 根据后端的响应最对应的操作
      if (res.code === 1) {
        // 登录成功
        // 设置一个登录过的标识符
        setcookie('token', 1, 30000)
        setcookie('nickname', res.nickname, 30000)
        setcookie('userId', res.userId, 30000)

        // 跳转到首页
        window.location.href = './index.html'
      } else {
        // 登录失败
        // 显示用户名或密码错误
        errText.className = 'active'
      }
    }
  })
})
