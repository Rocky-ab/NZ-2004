 // 0. 获取元素
 let imgBox = document.querySelector('.imgBox')
 let pointBox = document.querySelector('.pointBox')
 let banner = document.querySelector('.banner-r')
 let left = document.querySelector('.left')
 let right = document.querySelector('.right')
 let banner_width = banner.clientWidth
 let index = 1 // 默认显示第一张
 let timerId = 0
 let flag = true

 // 1. 设置焦点
 //    根据 ul 里面有多少个 li， 我就生成多少个 新的 li 放到 ol 里面
 setPoint()

 // 2. 复制元素
 //   把本身的第一个复制一份放在最后， 把本身的最后一个复制一份放在第一个
 copyEle()

 // 3. 自动轮播
 //    每间隔一段时间， 使用 move 函数移动一张
 autoPlay()

 // 4. 运动结束
 //    当到达最后一张的时候，瞬间定位到第一张， 让焦点配套

 // 5. 移入移出
 //    移入 banner 盒子的时候， 停止定时器， 移出的时候在打开
 overOut()

 // 6. 左右切换
 //    点击左按钮， 上一张 => index--，点击右按钮， 下一张 => index++
 leftRightEvent()

 // 7. 焦点切换
 //    点击哪一个焦点， 让对应的图片显示
 //    点击索引为 0 的焦点， 切换到 索引为 1 的 图片
 pointEvent()

 // 8. 解决问题
 //   8-1. 上一张的时候，到头没有切换到真的最后一张
 //   8-2. 解决点击太快的问题，因为太快， 加一个开关
 //   8-3. 解决切屏问题，切走的时候关闭定时器，切回来的时候再次打开
 docChange()


 function setPoint() {
   let pointNum = imgBox.children.length
   let frg = document.createDocumentFragment()
   for (let i = 0; i < pointNum; i++) {
     let li = document.createElement('li')
     li.innerHTML =i+1
     if (i === 0) li.className = 'active'
     frg.appendChild(li)
   }
   pointBox.appendChild(frg)
 }

 function copyEle() {
   let first = imgBox.firstElementChild.cloneNode(true)
   let last = imgBox.lastElementChild.cloneNode(true)
   imgBox.appendChild(first)
   imgBox.insertBefore(last, imgBox.firstElementChild)
   imgBox.style.width = imgBox.children.length * 100 + '%'
   imgBox.style.left = '-100%'
 }

 function autoPlay() {
   timerId = setInterval(() => {
     index++
     move(imgBox, 'left', -index * banner_width, moveEnd)
   }, 2000)
 }

 function moveEnd() {
   if (index >= imgBox.children.length - 1) {
     index = 1
     imgBox.style.left = -index * banner_width + 'px'
   }
   if (index <= 0) {
     index = imgBox.children.length - 2
     imgBox.style.left = -index * banner_width + 'px'
   }
   for (let i = 0; i < pointBox.children.length; i++) {
     pointBox.children[i].className = ''
   }
   pointBox.children[index - 1].className = 'active'
   flag = true
 }

 function overOut() {
   banner.onmouseover = () => clearInterval(timerId)
   banner.onmouseout = () => autoPlay()
 }

 function leftRightEvent() {
   left.onclick = function () {
     if (flag === false) return
     index--
     move(imgBox, 'left', -index * banner_width, moveEnd)
     flag = false
   }

   right.onclick = function () {
     if (flag === false) return
     index++
     move(imgBox, 'left', -index * banner_width, moveEnd)
     flag = false
   }
 }

 function pointEvent() {
   for (let i = 0; i < pointBox.children.length; i++) {
     pointBox.children[i].setAttribute('index', i)
     pointBox.children[i].onclick = function () {
       console.log(123)
       if (flag === false) {return}
       let point_index = this.getAttribute('index') - 0
       index = point_index + 1
       move(imgBox, 'left', -index * banner_width, moveEnd)
       flag = false
     }
   }
 }

 function docChange() {
   document.onvisibilitychange = function () {
     if (document.visibilityState === 'hidden') clearInterval(timerId)
     if (document.visibilityState === 'visible') autoPlay()
   }
 }